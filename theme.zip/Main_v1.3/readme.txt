Thanks for buying :)


The documentation is in the "documentation" folder. 
The HTML is in the "html" folder. 
The PSD files are in the 'psd' folder. 


All psd files are well-organized and labeled which makes the customization process more smooth and painless.


If you have any question please contact me using http://velikorodnov.ticksy.com/

If you like our product, don�t forget to rate it and subscribe for updates here http://themeforest.net/downloads 

Thank you! :)